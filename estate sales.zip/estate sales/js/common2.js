function quickInquiry() {
    alert("빠른 문의하기 기능은 준비 중입니다.");
}

function startVirtualTour() {
    alert("3D 가상 투어 기능은 준비 중입니다.");
}
